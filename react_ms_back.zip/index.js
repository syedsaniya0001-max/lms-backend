const express = require('express');
const mongoose = require('mongoose');//library,connects to DB,crud oop,create schema
const cors = require('cors');//Cross origin resource sharing,allow to talk fron &backend each other
require('dotenv').config();

const app = express();
app.use(cors());//activates cors
app.use(express.json({ limit: '50mb' }));

mongoose.connect(process.env.MONGO_URI).then(() => console.log('✅ MongoDB Connected'));


// --- SCHEMAS ---
const Student = mongoose.model('Student', new mongoose.Schema({
    name: String, roll: String, branch: String, entry: String, img: String
}));

const Faculty = mongoose.model('Faculty', new mongoose.Schema({
    name: String, fid: String, subject: String, dept: String, img: String
}));

const Librarian = mongoose.model('Librarian', new mongoose.Schema({
    name: String, dept: String, img: String
}));

// const Book = mongoose.model('Book', new mongoose.Schema({
//     name: String, author: String, code: String, cover: String,
//     status: String, studentName: String, issueDate: String, dueDate: String, fine: Number
// }));
// ADDED: Book Schema with all your library fields
const Book = mongoose.model('Book', new mongoose.Schema({
    name: String,
    author: String,
    code: String,
    cover: String,
    status: { type: String, default: "Available" },
    studentName: { type: String, default: "" },
    issueDate: { type: String, default: "" },
    dueDate: { type: String, default: "" },
    fine: { type: Number, default: 0 }
}));

// DYNAMIC ROUTE GENERATOR
const createApi = (path, Model) => {
    app.get(`/api/${path}`, async (req, res) => res.json(await Model.find()));
    app.post(`/api/${path}`, async (req, res) => res.json(await new Model(req.body).save()));
    app.put(`/api/${path}/:id`, async (req, res) => res.json(await Model.findByIdAndUpdate(req.params.id, req.body)));
    app.delete(`/api/${path}/:id`, async (req, res) => res.json(await Model.findByIdAndDelete(req.params.id)));
};

createApi('students', Student);
createApi('faculties', Faculty);
createApi('librarians', Librarian);
createApi('books', Book); // ADDED: Books API

app.listen(5000, () => console.log('🚀 Server running on port 5000'));